# GBIF Workbench deterministic export
# Generated from the live GBIF query and preview. Review filters before publication use.
#
# This script does TWO things, in order:
#   1. Submit a DOI-backed GBIF download via rgbif::occ_download() — this
#      is what serious reuse needs (rgbif::occ_search() is preview-only).
#   2. After the download is ready, point occ_download_get() at the file
#      and export it as gbif_occurrences.csv so cleaning_pipeline.R can
#      read it.
#
# After the download completes, copy the DOI printed at the end into
# citation_instructions.md and your manuscript methods section.

# --- 0. Install missing packages (one-time) --------------------------------
required_packages <- c("rgbif", "jsonlite", "dplyr", "readr")
to_install <- required_packages[!required_packages %in% installed.packages()[, "Package"]]
if (length(to_install) > 0) {
  install.packages(to_install, repos = "https://cloud.r-project.org")
}

library(rgbif)
library(jsonlite)
library(dplyr)
library(readr)

# --- 1. Submit the DOI-backed download ------------------------------------
# Set GBIF_USER, GBIF_PWD, and GBIF_EMAIL in your environment first
# (RGBIF_USERS_CACHE_DIR if you want a custom credential cache).
# Sys.setenv(GBIF_USER = "...", GBIF_PWD = "...", GBIF_EMAIL = "...")

download_request_json <- "{\n  \"notificationAddresses\": [\n    \"userEmail@example.org\"\n  ],\n  \"sendNotification\": true,\n  \"format\": \"SIMPLE_CSV\",\n  \"predicate\": {\n    \"type\": \"and\",\n    \"predicates\": [\n      {\n        \"type\": \"equals\",\n        \"key\": \"TAXON_KEY\",\n        \"value\": \"106\"\n      },\n      {\n        \"type\": \"equals\",\n        \"key\": \"COUNTRY\",\n        \"value\": \"BD\"\n      },\n      {\n        \"type\": \"equals\",\n        \"key\": \"YEAR\",\n        \"value\": \"2000,2026\"\n      }\n    ]\n  }\n}"
download_request <- fromJSON(download_request_json, simplifyVector = FALSE)
write_json(download_request, "gbif_download_request.json", auto_unbox = TRUE, pretty = TRUE)

# Translate the predicate into rgbif::pred_* helpers. The exact helper
# depends on the predicate shape GBIF Workbench generated — common
# examples below; uncomment the one that matches your download_request.
#
# For taxonKey + country + year:
#   occ_download(
#     pred("taxonKey", 5219404),
#     pred("country", "BR"),
#     pred("year", "2000,2025"),
#     format = "SIMPLE_CSV",
#     user = Sys.getenv("GBIF_USER"),
#     pwd  = Sys.getenv("GBIF_PWD"),
#     email = Sys.getenv("GBIF_EMAIL")
#   )
#
# For an "and" predicate from the JSON file:
#   download_key <- occ_download(
#     body = download_request,
#     user = Sys.getenv("GBIF_USER"),
#     pwd  = Sys.getenv("GBIF_PWD"),
#     email = Sys.getenv("GBIF_EMAIL")
#   )

download_key <- NULL  # fill in from occ_download() above
if (!is.null(download_key)) {
  # Wait for the download to complete and capture the DOI.
  result <- occ_download_wait(download_key, status_ping = 30)
  cat("GBIF download DOI:", result$doi, "\n")
  writeLines(result$doi, "gbif_doi.txt")

  # Import the SIMPLE_CSV archive and write a single CSV the cleaning
  # pipeline reads. GBIF names the file occurrence.txt inside the zip.
  raw_path <- occ_download_get(download_key, path = ".")
  occurrence_path <- file.path(dirname(raw_path), "occurrence.txt")
  if (file.exists(raw_path) && grepl("\.zip$", raw_path, ignore.case = TRUE)) {
    occurrence_path <- unzip(raw_path, list = TRUE)$Name[1]
    unzip(raw_path, exdir = dirname(raw_path))
    occurrence_path <- file.path(dirname(raw_path), occurrence_path)
  }
  if (file.exists(occurrence_path)) {
    records <- read_tsv(occurrence_path, show_col_types = FALSE)
    write_csv(records, "gbif_occurrences.csv")
    cat("Wrote", nrow(records), "records to gbif_occurrences.csv\n")
  } else {
    warning("Could not locate occurrence.txt in the GBIF download archive.")
  }
}

# --- 2. Quick preview (optional, NOT a substitute for the download) --------
query_params <- list(taxonKey = 106, country = c("BD"), year = "2000,2026", hasCoordinate = TRUE)
preview <- do.call(occ_search, c(query_params, list(limit = 300)))
cat("Preview matching records (occ_search, preview only):", preview$meta$count, "\n")
