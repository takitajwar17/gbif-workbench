# GBIF Workbench cleaning starter
#
# Reads gbif_occurrences.csv (produced by gbif_download.R after the
# DOI-backed download completes). If you downloaded manually, copy the
# archive's occurrence.txt to ./gbif_occurrences.csv first.
#
# Important: GBIF occurrence records are presence-only and opportunistic.
# These steps are a starting point, not a substitute for review of the
# GBIF issue facets shown in the app.

library(dplyr)
library(readr)

if (!file.exists("gbif_occurrences.csv")) {
  stop("gbif_occurrences.csv not found. Run gbif_download.R first, or copy occurrence.txt to gbif_occurrences.csv.")
}

records <- read_csv("gbif_occurrences.csv", show_col_types = FALSE)

cleaned <- records %>%
  filter(!is.na(decimalLatitude), !is.na(decimalLongitude)) %>%
  filter(is.na(hasGeospatialIssues) | hasGeospatialIssues == FALSE) %>%
  filter(is.na(year) | year >= 1800) %>%
  distinct(gbifID, .keep_all = TRUE)

if ("coordinateUncertaintyInMeters" %in% names(cleaned)) {
  cleaned <- cleaned %>%
    mutate(coordinateUncertaintyInMeters = as.numeric(coordinateUncertaintyInMeters))
}

# --- CoordinateCleaner block ----------------------------------------------
# Optional package — install once with:
#   install.packages("CoordinateCleaner")
# When installed, runs the standard biodiversity-cleaning flag set
# (capital, centroid, equal, zeros, gbifhq, institutions, biodiversity).
# When missing, the script keeps the dplyr-cleaned output above and
# prints a clear note so the user knows what they skipped.
if (requireNamespace("CoordinateCleaner", quietly = TRUE)) {
  cc_flags <- CoordinateCleaner::clean_coordinates(
    cleaned,
    lon = "decimalLongitude",
    lat = "decimalLatitude",
    species = "species",
    countries = "countryCode",
    tests = c("capitals", "centroids", "equal", "zeros", "gbifhq", "institutions", "biodiversity"),
    verbose = FALSE
  )
  cleaned <- cleaned[!cc_flags, ]
  cat("CoordinateCleaner removed", sum(cc_flags), "flagged records.\n")
} else {
  cat("CoordinateCleaner not installed; skipping taxon-aware coordinate flags.\n")
  cat("Install with install.packages(\"CoordinateCleaner\") to add capital/centroid/equal/zeros/gbifhq checks.\n")
}
# --------------------------------------------------------------------------

write_csv(cleaned, "gbif_occurrences_cleaned.csv")
cat("Wrote", nrow(cleaned), "cleaned records to gbif_occurrences_cleaned.csv\n")
