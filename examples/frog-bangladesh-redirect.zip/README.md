# GBIF Workbench Export

This archive is the export package produced by GBIF Workbench.

## Recommended order of operations

1. Read `study_plan.md` (or `study_plan.qmd` / `study_plan.ipynb`) for the
   complete workflow outline, including the interpreted scope, GBIF
   preview, triage, and recommended next steps.
2. Edit `gbif_query_params.json` if you need to adjust taxon, country,
   or year filters before submitting the download request.
3. Set your GBIF credentials (GBIF_USER, GBIF_PWD, GBIF_EMAIL) and
   run `gbif_download.R` or `gbif_download.py`. This submits a
   DOI-backed GBIF download and writes `gbif_doi.txt` and
   `gbif_occurrences.csv` for the cleaning pipeline.
4. Run `cleaning_pipeline.R` to produce `gbif_occurrences_cleaned.csv`.
   CoordinateCleaner is run automatically when installed; otherwise
   the script prints an install hint.
5. Paste the DOI from `gbif_doi.txt` into `citation_instructions.md`
   and your manuscript methods section.

## Important

The browser preview that produced this archive is *not* DOI-backed.
The DOI is generated when you run `gbif_download.R` or
`gbif_download.py` against the GBIF download API with your
credentials. Always cite the DOI, not the preview URL.

GBIF occurrence records are presence-only and opportunistic. The
methods, limitations, and triage text in this archive are starting
points, not a substitute for review of the GBIF issue facets and
coordinate-uncertainty signal that the workbench reports.

See `limitations_text.md` for the full list of caveats that apply
to your study.
