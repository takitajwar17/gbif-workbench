For exploratory preview use, cite GBIF and document the query URL used by GBIF Workbench.

For analysis or publication, create a GBIF download through GBIF.org, rgbif::occ_download(), or the GBIF download API, then cite the download DOI returned by GBIF.

Keep the generated predicate JSON and query parameters with your analysis files so reviewers can reproduce the data request.

GBIF search URL: https://www.gbif.org/occurrence/search?taxon_key=106&country=BD&year=2000%2C2026

GBIF API preview URL: https://api.gbif.org/v1/occurrence/search?taxonKey=106&country=BD&year=2000%2C2026