This deterministic export was generated because the optional AI workflow call did not complete in time.

Backend reason: examples/ static export

The code and text are grounded in the live GBIF query, preview counts, and triage already shown in the app.

GBIF occurrence records are presence-oriented and opportunistic unless paired with sampling-event, monitoring, effort, absence, or abundance data.

Do not interpret record counts as abundance. Treat gaps in countries, years, datasets, and coordinate precision as study-design limitations.

Review coordinate uncertainty before modelling.