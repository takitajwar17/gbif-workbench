The proposed study was interpreted as: Can GBIF support mapping jaguar (Panthera onca) records in Brazil since 2000?.

GBIF Workbench resolved the taxon as Panthera onca. The query scope was Brazil for 2000-2026.

The live GBIF occurrence preview found 4,382 matching records, including 3,602 records with usable coordinates and 3,881 records with date information.

The generated workflow preserves the GBIF search URL, occurrence API URL, SQL starter query, and download predicate so the preview can be reproduced before requesting a DOI-backed download.

Before publication use, inspect coordinate uncertainty, issue flags, dataset sources, basis of record, and temporal coverage.