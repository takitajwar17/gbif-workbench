# GBIF Workbench deterministic export
# Generated from the live GBIF query and preview. Review filters before publication use.
#
# This script does TWO things, in order:
#   1. Submit a DOI-backed GBIF download via the download API.
#   2. Poll for completion, then export to gbif_occurrences.csv for
#      cleaning_pipeline.R / pandas.
#
# After the download completes, copy the DOI printed at the end into
# citation_instructions.md and your manuscript methods section.

# pip install requests if needed.

import json
import os
import time
import zipfile

import requests

GBIF_OCCURRENCE_SEARCH = "https://api.gbif.org/v1/occurrence/search"
GBIF_DOWNLOAD_REQUEST = "https://api.gbif.org/v1/occurrence/download/request"
GBIF_DOWNLOAD_STATUS = "https://api.gbif.org/v1/occurrence/download/"

query_params = {
  "taxonKey": 5219404,
  "country": [
    "BR"
  ],
  "year": "2000,2026",
  "hasCoordinate": true,
  "hasGeospatialIssue": false
}

# --- 1. Preview (occurrences/search; NOT a substitute for the download) ----
preview = requests.get(GBIF_OCCURRENCE_SEARCH, params={**query_params, "limit": 300}, timeout=60)
preview.raise_for_status()
preview_json = preview.json()
print("Preview matching records (preview only):", preview_json.get("count"))

# --- 2. Submit the DOI-backed download ------------------------------------
download_request = {
  "notificationAddresses": [
    "userEmail@example.org"
  ],
  "sendNotification": true,
  "format": "SIMPLE_CSV",
  "predicate": {
    "type": "and",
    "predicates": [
      {
        "type": "equals",
        "key": "TAXON_KEY",
        "value": "5219404"
      },
      {
        "type": "equals",
        "key": "COUNTRY",
        "value": "BR"
      },
      {
        "type": "equals",
        "key": "YEAR",
        "value": "2000,2026"
      }
    ]
  }
}

with open("gbif_download_request.json", "w", encoding="utf-8") as handle:
    json.dump(download_request, handle, indent=2)

# Set GBIF_USER and GBIF_PWD (and optionally GBIF_EMAIL) in your environment.
auth = (os.environ["GBIF_USER"], os.environ["GBIF_PWD"])
response = requests.post(GBIF_DOWNLOAD_REQUEST, auth=auth, json=download_request, timeout=60)
response.raise_for_status()
download_key = response.text.strip().strip('"')
print("Submitted download key:", download_key)

# Poll for completion (RGBIF uses ~30s; matches GBIF's status refresh cadence).
while True:
    status_response = requests.get(GBIF_DOWNLOAD_STATUS + download_key, timeout=60)
    status_response.raise_for_status()
    status = status_response.json()
    if status.get("status") == "SUCCEEDED":
        doi = status.get("doi", "")
        print("GBIF download DOI:", doi)
        with open("gbif_doi.txt", "w", encoding="utf-8") as handle:
            handle.write(doi)
        break
    if status.get("status") == "FAILED":
        raise RuntimeError(f"GBIF download failed: {status}")
    time.sleep(30)

# Download the archive and write a single CSV the cleaning pipeline reads.
archive_url = status.get("downloadLink") or (GBIF_DOWNLOAD_STATUS + download_key + ".zip")
archive_path = "gbif_download.zip"
with requests.get(archive_url, stream=True, timeout=300) as r:
    r.raise_for_status()
    with open(archive_path, "wb") as handle:
        for chunk in r.iter_content(chunk_size=1 << 20):
            handle.write(chunk)

with zipfile.ZipFile(archive_path, "r") as zf:
    csv_name = next((n for n in zf.namelist() if n.endswith(".txt")), None)
    if csv_name is None:
        raise RuntimeError("GBIF download archive did not contain a .txt occurrence file.")
    with zf.open(csv_name) as src, open("gbif_occurrences.csv", "wb") as dst:
        dst.write(src.read())
print("Wrote gbif_occurrences.csv (TSV source renamed to .csv for tool compatibility)")
